<?php include('connect.php'); ?>
<?php 
	
    if(isset($_GET['action']))
    {
        $action = $_GET['action'];

        if($action != "delete")
        {
            $left = $_GET['left'];
            $right = $_GET['right'];
            $up = $_GET['up'];
            $down = $_GET['down'];

            $udregistrationsql = "INSERT INTO `location` (`leftd`, `rightd`, `up`, `down`) VALUES ($left, $right, $up, $down)";
            $resReg = mysqli_query($conn,$udregistrationsql);
            $count = mysqli_affected_rows($conn);
        }
        else{
            $udregistrationsql = "DELETE from `location`";
            $resReg = mysqli_query($conn,$udregistrationsql);
        }
    }
?>
<!DOCTYPE html>
<html><head> 
<script src="jquery/jquery-3.3.1.min.js"></script>
<style>
    .button {
  background-color: #808080;
  border-color: gold;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 13px;
  margin-left:600px;
  text-decoration: none;
   width:20%;     
}

a.button{
    width: 15%;
    border: 1px solid gold;
}
    

    
    body{
background-image:url('https://fcit.usf.edu/matrix/wp-content/uploads/2016/12/BotBackground-08-B.jpg');
background-attachment:fixed;
background-size:100% 100%;
}

    
h1{
position:absolute;
left:50px;



}
    A{
     margin-right: 700px;
    }
</style>
</head>

<body>
     <br>
    <br>
	
    

   
<input type="button" class="button" value="Right" onclick="lineRight()">
    <br>
    <br>
    <input type="button" class="button" value="Forward" onclick="lineForward()">
    &nbsp;
    
    <input type="text" height=500px; id="inputPx">
    <br>
    <br>
     <input type="button" class="button" value="Left" onclick="lineLeft()">
    <br>
    <br>
    <a href="hawra.php?action=delete" class="button">Delete</a>
    <br>
    <br>
    <input type="button" class="button" value="Save" onclick="saveLocation()">
    <br>
    <br>

    <canvas  id="myCanvas" width="400" height="250" style="border:2px solid gold;">
Your browser does not support the HTML canvas tag.</canvas>

 

<script>
var up = 350;
var down = 350;
var right = 200;
var left = 200;

function lineForward(){
    var inputPx = document.getElementById("inputPx").value;
    var c = document.getElementById("myCanvas");
    var ctx = c.getContext("2d");
    ctx.moveTo(left,down);
    ctx.lineTo(right,up - inputPx);
    ctx.stroke();

    up = up - inputPx;
    down = down - inputPx;
}

function lineLeft(){
    var inputPx = 25;
    var c = document.getElementById("myCanvas");
    var ctx = c.getContext("2d");
    ctx.moveTo(left - inputPx,down);
    ctx.lineTo(right,up);
    ctx.stroke();

    left = left - inputPx;
    right = right - inputPx;
}


function lineRight(){
    var inputPx = 25;
    var c = document.getElementById("myCanvas");
    var ctx = c.getContext("2d");
    ctx.moveTo(left,down);
    ctx.lineTo(right + inputPx,up);
    ctx.stroke();

    right = right + inputPx;
    left = left + inputPx;
}

function saveLocation(){

var formValues = {
    up: up,
    down: down,
    left: left,
    right: right,
    action: 'insert'
};
$.get("hawra.php", formValues, function(data){
    
});
}

</script>
    
</body>
</html>